# Question 1
setwd("path/to/your/folder")  # e.g., setwd("D:/Desktop/IT2120_Lab04")
branch_data <- read.csv("Exercise.txt")

print(branch_data)